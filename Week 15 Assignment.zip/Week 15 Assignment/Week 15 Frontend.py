from tkinter import *
import backend

def get_selected_row(event):
    global selected_tuple
    index = list1.curselection()[0]
    selected_tuple = list1.get(index)
    e1.delete(0, END)
    e1.insert(END, selected_tuple[1])
    e2.delete(0, END)
    e2.insert(END, selected_tuple[2])
    e3.delete(0, END)
    e3.insert(END, selected_tuple[3])
    e4.delete(0, END)
    e4.insert(END, selected_tuple[4])
    e5.delete(0, END)
    e5.insert(END, selected_tuple[5])

def view_command():
    list1.delete(0, END)
    for row in backend.view():
        list1.insert(END, row)

def search_command():
    list1.delete(0, END)
    for row in backend.search(title_text.get(), author_text.get(), year_text.get(), isbn_text.get(), genre_text.get()):
        list1.insert(END, row)

def add_command():
    backend.insert(title_text.get(), author_text.get(), year_text.get(), isbn_text.get(), genre_text.get())
    list1.delete(0, END)
    list1.insert(END, (title_text.get(), author_text.get(), year_text.get(), isbn_text.get(), genre_text.get()))

def delete_command():
    backend.delete(selected_tuple[0])
    view_command()

def update_command():
    backend.update(selected_tuple[0], title_text.get(), author_text.get(), year_text.get(), isbn_text.get(), genre_text.get())
    view_command()

window = Tk()
window.wm_title("BookStore")

Label(window, text="Title").grid(row=0, column=0)
Label(window, text="Author").grid(row=0, column=2)
Label(window, text="Year").grid(row=1, column=0)
Label(window, text="ISBN").grid(row=1, column=2)
Label(window, text="Genre").grid(row=2, column=0)

title_text = StringVar()
author_text = StringVar()
year_text = StringVar()
isbn_text = StringVar()
genre_text = StringVar()

e1 = Entry(window, textvariable=title_text)
e1.grid(row=0, column=1)

e2 = Entry(window, textvariable=author_text)
e2.grid(row=0, column=3)

e3 = Entry(window, textvariable=year_text)
e3.grid(row=1, column=1)

e4 = Entry(window, textvariable=isbn_text)
e4.grid(row=1, column=3)

e5 = Entry(window, textvariable=genre_text)
e5.grid(row=2, column=1)

list1 = Listbox(window, height=8, width=50)
list1.grid(row=3, column=0, rowspan=6, columnspan=2)

sb1 = Scrollbar(window)
sb1.grid(row=3, column=2, rowspan=6)

list1.configure(yscrollcommand=sb1.set)
sb1.configure(command=list1.yview)

list1.bind('<<ListboxSelect>>', get_selected_row)

Button(window, text="View all", width=12, command=view_command).grid(row=3, column=3)
Button(window, text="Search entry", width=12, command=search_command).grid(row=4, column=3)
Button(window, text="Add entry", width=12, command=add_command).grid(row=5, column=3)
Button(window, text="Update selected", width=12, command=update_command).grid(row=6, column=3)
Button(window, text="Delete selected", width=12, command=delete_command).grid(row=7, column=3)
Button(window, text="Close", width=12, command=window.destroy).grid(row=8, column=3)

window.mainloop()